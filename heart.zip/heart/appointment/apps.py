from django.apps import AppConfig


class AppointmentConfig(AppConfig):
    name = 'appointment'
